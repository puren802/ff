<?php
session_start();
$con = mysqli_connect('localhost', 'root', 'qwerqwer', 'final_db');


if(isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$query = "SELECT username, password FROM users 
	WHERE username='$username' AND password='$password'";
	
	$result = mysqli_query($con, $query);
	if(mysqli_num_rows($result) > 0) {
		$_SESSION['username'] = $_POST['username'];		
		header("Location:members.php");
	}
	else {
		header("Location:ex.php");
	}
}

?>